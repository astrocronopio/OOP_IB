#include "ejer_10.h"

ejer_10 test(42);

/* 
int main(int argc, char const *argv[])
{   //Testing
    test.print();
    test.set_ejer_10(54);
    test.print();
    return 0;
}
 */